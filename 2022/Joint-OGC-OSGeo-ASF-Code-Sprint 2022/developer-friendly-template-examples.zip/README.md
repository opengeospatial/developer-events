## ReDoc examples

Run the examples using python.

`python -m SimpleHTTPServer 8080`

Then navigate to the examples.

IFrame Example http://localhost:8080/example-iframe.html

Pandoc Example http://localhost:8080/example-pandoc.html
